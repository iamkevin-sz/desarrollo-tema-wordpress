# desarrollo-tema-wordpress
Se hará un desarrollo de tema a medida en wordpress con php, js, css, html y ajax
